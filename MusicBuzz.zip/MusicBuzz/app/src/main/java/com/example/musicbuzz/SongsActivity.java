package com.example.musicbuzz;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.musicbuzz.database.BuzzModel;
import com.example.musicbuzz.database.MusicEntity;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class SongsActivity extends AppCompatActivity   {

    Songs s;
    ImageView imageView;
    TextView na,li,des;
    String idtrack,img,name,link,dec;
    LikeButton likeButton;

    BuzzModel buzzModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs2);

        imageView=findViewById(R.id.imag);
        na=findViewById(R.id.tra);
        li=findViewById(R.id.vid);
        des=findViewById(R.id.desc);
        likeButton=findViewById(R.id.heartid);

        buzzModel= ViewModelProviders.of(this).get(BuzzModel.class);


        idtrack=getIntent().getStringExtra("idtrack");
        img=getIntent().getStringExtra("img");
        name=getIntent().getStringExtra("id");
        link=getIntent().getStringExtra("lin");
        dec=getIntent().getStringExtra("descrip");

        //Toast.makeText(this, ""+dec, Toast.LENGTH_SHORT).show();
        Picasso.with(s).load(img).placeholder(R.mipmap.ic_launcher).into(imageView);
        na.setText(name);
        li.setText(link);
        des.setText(dec);

        li.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri u= Uri.parse(link);
                Intent intent=new Intent(Intent.ACTION_VIEW,u);
                startActivity(intent);
            }
        });



        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {

                MusicEntity entity=new MusicEntity();
                entity.setIdstrtracking(idtrack);
                entity.setStrtrackname(name);
                entity.setStrimg(img);
                entity.setStrdec(dec);
                entity.setStrlink(link);

                buzzModel.insdata(entity);
                Toast.makeText(SongsActivity.this, getResources().getString(R.string.like), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                MusicEntity entity=new MusicEntity();
                entity.setIdstrtracking(idtrack);
                entity.setStrtrackname(name);
                entity.setStrimg(img);
                entity.setStrdec(dec);
                entity.setStrlink(link);

                buzzModel.deldata(entity);
                Toast.makeText(SongsActivity.this, getResources().getString(R.string.deletefav), Toast.LENGTH_SHORT).show();

            }
        });

        enablefavbuzz();

    }

    private void enablefavbuzz() {
        buzzModel.getLis().observe(this, new Observer<List<MusicEntity>>() {
            @Override
            public void onChanged(List<MusicEntity> musicEntities) {
                for (int b=0;b<musicEntities.size();b++)
                {
                    String strtrack=musicEntities.get(b).getIdstrtracking();

                    if (strtrack.equalsIgnoreCase(idtrack)){
                        likeButton.setLiked(true);
                    }
                }
            }
        });
    }


}
