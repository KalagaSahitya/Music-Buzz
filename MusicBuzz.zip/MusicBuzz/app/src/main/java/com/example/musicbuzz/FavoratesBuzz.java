package com.example.musicbuzz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.musicbuzz.database.BuzzModel;
import com.example.musicbuzz.database.MusicEntity;
import com.squareup.picasso.Picasso;

import java.util.List;

public class FavoratesBuzz extends AppCompatActivity {


    BuzzModel buzzModel;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorates_buzz);
        recyclerView=findViewById(R.id.favrec);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        buzzModel= ViewModelProviders.of(this).get(BuzzModel.class);
        buzzModel.getLis().observe(this, new Observer<List<MusicEntity>>() {
            @Override
            public void onChanged(List<MusicEntity> musicEntities) {

                if (musicEntities.size()==0){
                    Toast.makeText(FavoratesBuzz.this, getResources().getString(R.string.no_fav), Toast.LENGTH_SHORT).show();
                }
                FavoAdapter adapter=new FavoAdapter(FavoratesBuzz.this,musicEntities);
                recyclerView.setAdapter(adapter);
            }
        });
    }

    private class FavoAdapter extends RecyclerView.Adapter<FavoAdapter.FavoViewInfo> {

       FavoratesBuzz favoratesBuzz;
       List<MusicEntity> musicEntities;
        public FavoAdapter(FavoratesBuzz favoratesBuzz, List<MusicEntity> musicEntities) {
            this.favoratesBuzz=favoratesBuzz;
            this.musicEntities=musicEntities;
        }

        @NonNull
        @Override
        public FavoAdapter.FavoViewInfo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(favoratesBuzz).inflate(R.layout.song,parent,false);
            return new FavoViewInfo(view);
        }

        @Override
        public void onBindViewHolder(@NonNull FavoAdapter.FavoViewInfo holder, int position) {

            Picasso.with(favoratesBuzz).load(musicEntities.get(position).getStrimg()).placeholder(R.mipmap.ic_launcher).error(R.mipmap.ic_launcher).into(holder.img);
            holder.textView.setText(musicEntities.get(position).getStrtrackname());
        }

        @Override
        public int getItemCount() {
            return musicEntities.size();
        }

        public class FavoViewInfo extends RecyclerView.ViewHolder implements View.OnClickListener {
            ImageView img;
            TextView textView;

            public FavoViewInfo(@NonNull View itemView) {
                super(itemView);
                textView=itemView.findViewById(R.id.tra);
                img=itemView.findViewById(R.id.img);
                itemView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                int p=getAdapterPosition();
                Intent i=new Intent(favoratesBuzz,SongsActivity.class);
                i.putExtra("idtrack",musicEntities.get(p).getIdstrtracking());
                i.putExtra("img",musicEntities.get(p).getStrimg());
                i.putExtra("id",musicEntities.get(p).getStrtrackname());
                i.putExtra("lin",musicEntities.get(p).getStrlink());
                i.putExtra("descrip",musicEntities.get(p).getStrdec());
                favoratesBuzz.startActivity(i);
            }
        }
    }
}
