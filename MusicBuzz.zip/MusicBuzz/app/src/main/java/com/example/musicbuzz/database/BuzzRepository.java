package com.example.musicbuzz.database;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class BuzzRepository {
    private Dao_Buzz daofavour;
    private LiveData<List<MusicEntity>> favour;
    public BuzzRepository(Application favourapp){
        Buzzroomdatabase favdb=Buzzroomdatabase.getDatabase(favourapp);
        daofavour =favdb.dao();
        favour=daofavour.roomdata();
    }
    public LiveData<List<MusicEntity>> getdata() {
        return favour;
    }

    public void insertdb(MusicEntity fa){
        new Asynchro(daofavour).execute(fa);

    }


    private class Asynchro extends AsyncTask<MusicEntity,Void,Void> {

       Dao_Buzz daofavouri;

        public Asynchro(Dao_Buzz daofavour) {
            this.daofavouri=daofavour;
        }

        @Override
        protected Void doInBackground(MusicEntity... favourites) {
            daofavour.inser(favourites[0]);
            return null;
        }
    }
    public void deletedb(MusicEntity f){
        new Asynchron(daofavour).execute(f);

    }


    private class Asynchron extends AsyncTask<MusicEntity,Void,Void> {

        Dao_Buzz daofavourite;

        public Asynchron(Dao_Buzz daofavour) {
            this.daofavourite=daofavour;
        }

        @Override
        protected Void doInBackground(MusicEntity... musicEntities) {
            daofavourite.dely(musicEntities[0]);
            return null;
        }
    }
}
