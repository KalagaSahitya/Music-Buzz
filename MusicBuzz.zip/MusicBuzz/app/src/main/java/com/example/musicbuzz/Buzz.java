package com.example.musicbuzz;

public class Buzz {

    String artistid;
    String artistname;
    String style;
    String genre;
    String artistthumb;
    String country;

    public Buzz(){

    }

    public Buzz(String artistid, String artistname, String style, String genre, String artistthumb, String country) {
        this.artistid = artistid;
        this.artistname = artistname;
        this.style = style;
        this.genre = genre;
        this.artistthumb = artistthumb;
        this.country = country;
    }

    public String getArtistid() {
        return artistid;
    }

    public void setArtistid(String artistid) {
        this.artistid = artistid;
    }

    public String getArtistname() {
        return artistname;
    }

    public void setArtistname(String artistname) {
        this.artistname = artistname;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getArtistthumb() {
        return artistthumb;
    }

    public void setArtistthumb(String artistthumb) {
        this.artistthumb = artistthumb;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

}