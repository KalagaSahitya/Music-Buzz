package com.example.musicbuzz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText editText;
    ConnectivityManager connectivityManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.edit);
        connectivityManager= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    public void Search(View view) {

        if ((connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(connectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) ) {

            String search=editText.getText().toString();

            if (TextUtils.isEmpty(search)){
                Toast.makeText(this, getResources().getString(R.string.enterdata), Toast.LENGTH_SHORT).show();
            }
            else {
                Intent intent=new Intent(this,MusicActivity.class);
                intent.putExtra("search",search);
                startActivity(intent);
            }
        }
        else {
            Toast.makeText(this, getResources().getString(R.string.pinter), Toast.LENGTH_SHORT).show();
        }




    }
}
