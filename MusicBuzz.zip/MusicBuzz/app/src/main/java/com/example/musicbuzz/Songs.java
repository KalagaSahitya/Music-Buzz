package com.example.musicbuzz;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Songs extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    Integer n;
    String id;
    RecyclerView rview;
    ArrayList<MySongs> songlist;
    private Object MusicActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_songs);
        id=getIntent().getStringExtra("idd");
        rview=findViewById(R.id.recycler);
        //Toast.makeText(this, ""+id, Toast.LENGTH_SHORT).show();


        Bundle bundle=new Bundle();
        bundle.putString("idd",id);
        getSupportLoaderManager().initLoader(1,bundle,this);


    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(final int id, @Nullable final Bundle args) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Nullable
            @Override
            public String loadInBackground() {

                String url="https://www.theaudiodb.com/api/v1/json/1/mvid.php?i="+args.getString("idd");

                try {
                    URL ur=new URL(url);
                    HttpURLConnection httpurl= (HttpURLConnection) ur.openConnection();
                    httpurl.connect();;
                    InputStream inputStream=httpurl.getInputStream();
                    BufferedReader buffer=new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder build=new StringBuilder();
                    String st="";
                    while ((st=buffer.readLine())!=null){
                        build.append(st);
                    }
                    return build.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {

        //Log.d("ding",data);
       // Toast.makeText(this, ""+data, Toast.LENGTH_SHORT).show();
        songlist=new ArrayList<MySongs>();
        try {
            JSONObject object=new JSONObject(data);
            JSONArray arr=object.getJSONArray( "mvids");
            for (int i=0;i<arr.length();i++){
                JSONObject object1=arr.getJSONObject(i);
                String idtrack=object1.getString("idTrack");
                String track=object1.getString(  "strTrack");
                String image=object1.getString( "strTrackThumb");
                String desc=object1.getString( "strDescriptionEN");
                String link=object1.getString( "strMusicVid");
                MySongs mySongs=new MySongs();
                mySongs.setIdtrack(idtrack);
                mySongs.setTrack(track);
                mySongs.setImage(image);
                mySongs.setDes(desc);
                mySongs.setLink(link);
                songlist.add(mySongs);

            }
            SongsAdapter songsAdapter=new SongsAdapter(Songs.this,songlist);
            rview.setAdapter(songsAdapter);
            rview.setLayoutManager(new LinearLayoutManager(Songs.this));


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
