package com.example.musicbuzz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MusicActivity extends AppCompatActivity {

    FirebaseAuth nAuth;
    RecyclerView recyclerView;
    ArrayList<Buzz> arrayList;
    String search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        recyclerView=findViewById(R.id.Buzz);

        search = getIntent().getStringExtra("search");
        nAuth=FirebaseAuth.getInstance();
        MusicBuzz music=new MusicBuzz(this);
        music.execute();




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.widget:
                SharedPreferences sp =getSharedPreferences("name",MODE_PRIVATE);
                SharedPreferences.Editor edit=sp.edit();
                StringBuilder builder=new StringBuilder();
                StringBuilder builder1=new StringBuilder();
                for (int i=0;i<arrayList.size();i++) {
                    builder.append(arrayList.get(i).getArtistname()+"\n");
                    builder1.append(arrayList.get(i).getArtistname()+"\n");
                }
                edit.putString("save",builder1.toString());
                edit.commit();

                Intent in=new Intent(getApplicationContext(),NewAppWidget.class);
                in.setAction("android.appwidget.action.APPWIDGET_UPDATE");
                int widgetbake[]= AppWidgetManager.getInstance(getApplicationContext()).getAppWidgetIds(new ComponentName(getApplication(),NewAppWidget.class));
                in.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,widgetbake);
                sendBroadcast(in);



                break;
            case R.id.feedback:
                Intent intent=new Intent(this,Feedback.class);
                startActivity(intent);
                break;

            case R.id.fav:

                Intent i=new Intent(this,FavoratesBuzz.class);
                startActivity(i);
                break;

            case R.id.logout:
                nAuth.signOut();
                Intent tents=new Intent(this,LoginActivity.class);
                startActivity(tents);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private class MusicBuzz extends AsyncTask<String,Void,String> {
        MusicActivity musicActivity;
        public MusicBuzz(MusicActivity musicActivity) {
            this.musicActivity=musicActivity;
        }


        @Override
        protected String doInBackground(String... strings) {
            String ur="https://www.theaudiodb.com/api/v1/json/1/search.php?s="+search;
            try {
                URL url=new URL(ur);
                HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.connect();
                InputStream stream=httpURLConnection.getInputStream();
                BufferedReader buffer=new BufferedReader(new InputStreamReader(stream));
                StringBuilder builder=new StringBuilder();
                String str="";
                while ((str=buffer.readLine())!=null){
                    builder.append(str);
                }
                return builder.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            arrayList=new ArrayList<>();
            try {
                JSONObject jsonObject=new JSONObject(s);
                JSONArray array=jsonObject.getJSONArray("artists");
                for (int i=0;i<array.length();i++){
                    JSONObject obj=array.getJSONObject(i);
                    String id=obj.getString("idArtist");
                    String troupename=obj.getString("strArtist");
                    String style=obj.getString("strStyle");
                    String genre=obj.getString("strGenre");
                    String thumb=obj.getString( "strArtistThumb");
                    String country=obj.getString( "strCountry");

                    Buzz b=new Buzz();
                    b.setArtistid(id);
                    b.setArtistname(troupename);
                    b.setStyle(style);
                    b.setGenre(genre);
                    b.setArtistthumb(thumb);
                    b.setCountry(country);
                    arrayList.add(b);
                   // Toast.makeText(musicActivity, ""+arrayList, Toast.LENGTH_SHORT).show();

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            MusicAdapter adapter=new MusicAdapter(musicActivity,arrayList);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(musicActivity));
            //Toast.makeText(musicActivity, ""+s, Toast.LENGTH_SHORT).show();
        }

    }
}
