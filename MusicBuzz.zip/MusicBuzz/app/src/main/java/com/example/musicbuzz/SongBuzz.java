package com.example.musicbuzz;

public class SongBuzz {
    Integer id;
    Integer albumid;
    String trackname,image;

    public SongBuzz(Integer id, Integer albumid, String trackname, String image) {
        this.id = id;
        this.albumid = albumid;
        this.trackname = trackname;
        this.image = image;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAlbumid() {
        return albumid;
    }

    public void setAlbumid(Integer albumid) {
        this.albumid = albumid;
    }

    public String getTrackname() {
        return trackname;
    }

    public void setTrackname(String trackname) {
        this.trackname = trackname;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
