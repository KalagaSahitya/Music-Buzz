package com.example.musicbuzz.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class MusicEntity {


    @PrimaryKey
            @NonNull
    String idstrtracking;

    String strtrackname;
    String strimg;
    String strdec;
    String strlink;

    @NonNull
    public String getIdstrtracking() {
        return idstrtracking;
    }

    public void setIdstrtracking(@NonNull String idstrtracking) {
        this.idstrtracking = idstrtracking;
    }

    public String getStrtrackname() {
        return strtrackname;
    }

    public void setStrtrackname(String strtrackname) {
        this.strtrackname = strtrackname;
    }

    public String getStrimg() {
        return strimg;
    }

    public void setStrimg(String strimg) {
        this.strimg = strimg;
    }

    public String getStrdec() {
        return strdec;
    }

    public void setStrdec(String strdec) {
        this.strdec = strdec;
    }

    public String getStrlink() {
        return strlink;
    }

    public void setStrlink(String strlink) {
        this.strlink = strlink;
    }
}
