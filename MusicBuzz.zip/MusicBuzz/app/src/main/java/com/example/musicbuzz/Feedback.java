package com.example.musicbuzz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Feedback extends AppCompatActivity {

    EditText ed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        ed=findViewById(R.id.enterfeed);
    }

    public void Submit(View view) {

        String user=ed.getText().toString();
        if (!TextUtils.isEmpty(user)) {
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("message");

            String var=myRef.push().getKey();
            myRef.child(var).setValue(user);

            Toast.makeText(this, getResources().getString(R.string.sendfeedback), Toast.LENGTH_SHORT).show();

        }
        else {
            Toast.makeText(this, getResources().getString(R.string.enterfeedback), Toast.LENGTH_SHORT).show();
        }

    }
}
