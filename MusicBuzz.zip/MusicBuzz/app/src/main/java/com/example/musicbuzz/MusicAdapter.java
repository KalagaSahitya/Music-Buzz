package com.example.musicbuzz;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.Myviewinfo> {
    MusicActivity mactivity;
    ArrayList<Buzz> buzzArrayList;



    public MusicAdapter(MusicActivity musicBuzz, ArrayList<Buzz> arrayList) {
        mactivity=musicBuzz;
        this.buzzArrayList=arrayList;
    }

    @NonNull
    @Override
    public MusicAdapter.Myviewinfo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mactivity).inflate(R.layout.row,parent,false);
        return new Myviewinfo(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicAdapter.Myviewinfo holder, int position) {
        Picasso.with(mactivity).load(buzzArrayList.get(position).getArtistthumb()).error(R.mipmap.ic_launcher).into(holder.img);
        holder.nam_text.setText(buzzArrayList.get(position).getArtistname());
        holder.sty_text.setText(buzzArrayList.get(position).getStyle());
        holder.gen_text.setText(buzzArrayList.get(position).getGenre());
        holder.coun_text.setText(buzzArrayList.get(position).getCountry());
    }

    @Override
    public int getItemCount() {
        return buzzArrayList.size();
    }

    public class Myviewinfo extends RecyclerView.ViewHolder {
        ImageView img;
        TextView nam_text,sty_text,gen_text,coun_text,button;

        public Myviewinfo(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.image);
            nam_text=itemView.findViewById(R.id.name);
            sty_text=itemView.findViewById(R.id.style);
            gen_text=itemView.findViewById(R.id.genre);
            coun_text=itemView.findViewById(R.id.country);
            button=itemView.findViewById(R.id.button);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int p=getAdapterPosition();


                   // Toast.makeText(mactivity, buzzArrayList.get(p).getArtistid(), Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(mactivity,Songs.class);
                    i.putExtra("idd",buzzArrayList.get(p).getArtistid());
                   /*// i.putExtra("label",buzzArrayList.get(p).get)
                    i.putExtra("nam",buzzArrayList.get(p).getArtistname());
                    i.putExtra("sty",buzzArrayList.get(p).getStyle());
                    i.putExtra("gen",buzzArrayList.get(p).getGenre());
                    i.putExtra("coun",buzzArrayList.get(p).getCountry());*/
                    mactivity.startActivity(i);
                }
            });

        }
    }
}
