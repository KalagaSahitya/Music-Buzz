package com.example.musicbuzz;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SongsAdapter extends RecyclerView.Adapter<SongsAdapter.Myview> {
    Songs s;
    ArrayList<MySongs> msongslist;

    public SongsAdapter(Songs songs, ArrayList<MySongs> songlist) {
        s=songs;
        msongslist=songlist;
    }

    @NonNull
    @Override
    public SongsAdapter.Myview onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(s).inflate(R.layout.song,parent,false);
        return new Myview(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SongsAdapter.Myview holder, int position) {
        Picasso.with(s).load(msongslist.get(position).getImage()).placeholder(R.mipmap.ic_launcher).error(R.mipmap.ic_launcher).into(holder.im);
        holder.tr.setText(msongslist.get(position).getTrack());


    }

    @Override
    public int getItemCount() {
        return msongslist.size();
    }

    public class Myview extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView im;
        TextView tr;
        public Myview(@NonNull View itemView) {
            super(itemView);
            tr=itemView.findViewById(R.id.tra);
            im=itemView.findViewById(R.id.img);
            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View view) {
            int p=getAdapterPosition();
            Intent i=new Intent(s,SongsActivity.class);
            i.putExtra("idtrack",msongslist.get(p).getIdtrack());
            i.putExtra("img",msongslist.get(p).getImage());
            i.putExtra("id",msongslist.get(p).getTrack());
            i.putExtra("lin",msongslist.get(p).getLink());
            i.putExtra("descrip",msongslist.get(p).getDes());
            s.startActivity(i);

        }
    }
}
