package com.example.musicbuzz.database;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface Dao_Buzz {
    @Insert
    void inser(MusicEntity fav);

    @Query("select * from MusicEntity")
    public LiveData<List<MusicEntity>> roomdata();

    @Delete
    void dely(MusicEntity fav);
}
