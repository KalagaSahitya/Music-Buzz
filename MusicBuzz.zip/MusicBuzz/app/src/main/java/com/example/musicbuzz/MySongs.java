package com.example.musicbuzz;

public class MySongs {

    String idtrack,track,link,image,des;

    public MySongs() {
        this.track = track;
        this.link = link;
        this.image = image;
        this.des = des;
    }

    public String getIdtrack() {
        return idtrack;
    }

    public void setIdtrack(String idtrack) {
        this.idtrack = idtrack;
    }

    public String getTrack() {
        return track;
    }

    public void setTrack(String track) {
        this.track = track;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
