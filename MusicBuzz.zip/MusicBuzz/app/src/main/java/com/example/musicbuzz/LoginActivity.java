package com.example.musicbuzz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    TextView emailid,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        emailid=findViewById(R.id.email);
        password=findViewById(R.id.password);
        mAuth=FirebaseAuth.getInstance();

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mAuth.getCurrentUser()!=null) {
            Intent tent=new Intent(LoginActivity.this,MainActivity.class);
            startActivity(tent);
        }
    }

    public void SignUp(View view) {
        Intent i=new Intent(LoginActivity.this,RegisterActivity.class);
        startActivity(i);
    }

    public void SignIn(View view) {
        String mail=emailid.getText().toString();
        String word=password.getText().toString();
        if (!TextUtils.isEmpty(mail)) {
            if (!TextUtils.isEmpty(word)) {
                mAuth.signInWithEmailAndPassword(mail,word)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                   Intent in=new Intent(LoginActivity.this,MainActivity.class);
                                   startActivity(in);
                                } else {
                                    // If sign in fails, display a message to the user.

                                    Toast.makeText(LoginActivity.this, getResources().getString(R.string.afailed),
                                            Toast.LENGTH_SHORT).show();
                                }

                                // ...
                            }
                        });
            }
            else {
                Toast.makeText(this, getResources().getString(R.string.epassword), Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, getResources().getString(R.string.email), Toast.LENGTH_SHORT).show();
        }
    }
}
