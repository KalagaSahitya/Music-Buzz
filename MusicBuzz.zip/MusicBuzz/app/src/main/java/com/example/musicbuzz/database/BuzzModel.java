package com.example.musicbuzz.database;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class BuzzModel extends AndroidViewModel {

    BuzzRepository rep;
    LiveData<List<MusicEntity>> lis;

    public BuzzModel(@NonNull Application application) {
        super(application);
        rep=new BuzzRepository(application);
        lis=rep.getdata();
    }

    public LiveData<List<MusicEntity>> getLis() {
        return lis;
    }
    public void insdata(MusicEntity favo){
        rep.insertdb(favo);
    }
    public void deldata(MusicEntity favou){
        rep.deletedb(favou);
    }
}
